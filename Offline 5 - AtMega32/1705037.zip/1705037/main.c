/*
 * ledmatrixOffline5.c
 *
 * Created: 4/10/2021 5:47:29 PM
 * Author : User
 */ 
#define F_CPU 1000000
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

int mode = 0;
unsigned char temp_a;
unsigned char temp_b;
ISR(INT0_vect)
{
	mode = 1-mode;
}

void showsymbolJ()
{
	_delay_ms(5);
	PORTA = PORTA<<1;
	PORTB = ~PORTB;
	_delay_ms(5);
	
	PORTA = PORTA<<1;
	_delay_ms(5);
	
	PORTA = PORTA<<1;
	PORTB = ~PORTB;
	PORTB = PORTB<<1;
	PORTB = ~PORTB;
	_delay_ms(5);
}

int main(void)
{
	
    /* Replace with your application code */
	DDRA = 0b11111111;
	DDRB = 0b11111111;
	
	GICR = (1<<INT0);
	MCUCR = MCUCR & 0b11111100;
	sei();
	
	temp_a=0b00000100;
	temp_b=0b00000001;
    while (1) 
    {
		if(mode==0){
			PORTA = temp_a;
			PORTB = temp_b;
			showsymbolJ();
		}
		else if(mode==1)
		{
			int count = 0;
			while(1) {
				PORTA = temp_a;
				PORTB = temp_b;
				showsymbolJ();
				count++;
				
				if(count==20)
				{
					break;
				}
			}
			if(temp_b==1)
			{
				temp_b=128;
			}
			else
			{
				temp_b=temp_b>>1;
			}
			temp_a = 0b00000100;
			
		}
		
    }
}

